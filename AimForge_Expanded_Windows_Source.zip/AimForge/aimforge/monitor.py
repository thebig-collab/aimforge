import csv, os, time, subprocess
from collections import deque
import psutil

class PerformanceMonitor:
    def __init__(self):
        self.samples = deque(maxlen=240)
        self.csv_path = None
        psutil.cpu_percent(interval=None)

    def set_csv(self, path):
        self.csv_path = path
        self.samples.clear()

    def _read_csv(self):
        if not self.csv_path or not os.path.isfile(self.csv_path): return
        try:
            with open(self.csv_path, encoding="utf-8-sig", newline="") as f:
                rows = list(csv.DictReader(f))
            keys = ("MsBetweenPresents", "msBetweenPresents",
                    "MsBetweenDisplayChange", "msBetweenDisplayChange")
            self.samples.clear()
            for row in rows[-240:]:
                key = next((k for k in keys if k in row), None)
                if key:
                    try:
                        ms = float(row[key])
                        if 0.05 <= ms <= 1000: self.samples.append(ms)
                    except (ValueError, TypeError): pass
        except (OSError, csv.Error): pass

    def _nvidia_metrics(self):
        # NVIDIA telemetry is available when the vendor driver exposes nvidia-smi.
        try:
            r=subprocess.run(["nvidia-smi","--query-gpu=temperature.gpu,utilization.gpu,memory.used,clocks.gr, power.draw","--format=csv,noheader,nounits"],capture_output=True,text=True,timeout=1,check=True)
            parts=[x.strip() for x in r.stdout.splitlines()[0].split(",")]
            return {"gpu_temp":float(parts[0]),"gpu_usage":float(parts[1]),"vram_used":float(parts[2])/1024,"gpu_clock":float(parts[3]),"gpu_power":float(parts[4])}
        except Exception: return {"gpu_temp":None,"gpu_usage":None,"vram_used":None,"gpu_clock":None,"gpu_power":None}

    def snapshot(self):
        self._read_csv()
        fps = avg = low = None
        if self.samples:
            vals = list(self.samples)
            fps = 1000.0 / vals[-1]
            avg = 1000.0 / (sum(vals) / len(vals))
            ordered = sorted(1000.0 / x for x in vals)
            low = sum(ordered[:max(1, (len(ordered)+99)//100)]) / max(1, (len(ordered)+99)//100)
        vm = psutil.virtual_memory()
        gpu=self._nvidia_metrics()
        return {"fps":fps, "avg_fps":avg, "one_percent_low":low,
                "cpu_usage":psutil.cpu_percent(interval=None),
                "ram_used_gb":(vm.total-vm.available)/1024**3,
                "ram_total_gb":vm.total/1024**3, "timestamp":time.time(),
                "cpu_temp":None, **gpu, "cpu_clock":None}
